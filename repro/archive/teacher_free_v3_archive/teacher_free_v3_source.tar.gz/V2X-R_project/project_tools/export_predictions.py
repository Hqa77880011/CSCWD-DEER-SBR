#!/usr/bin/env python3
"""Export every sample, including empty predictions, with stable anchor IDs.

Decoding intentionally does not call the legacy postprocessor, which applies
additional box filters and a score threshold that differ from project_fix_v1.
"""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from opencood.project.training import select_model_inputs, to_device, seed_everything
from opencood.project.config import file_sha256


def decode_predictions(output, anchors, sample_ids, score_floor=0.001):
    deltas = output["rm"].float().permute(0, 2, 3, 1).contiguous().reshape(len(sample_ids), -1, 7)
    scores = output["psm"].float().sigmoid().permute(0, 2, 3, 1).contiguous().reshape(len(sample_ids), -1)
    anchors = torch.as_tensor(anchors, device=deltas.device, dtype=deltas.dtype).reshape(1, -1, 7)
    if anchors.shape[1] != deltas.shape[1] or scores.shape[1] != deltas.shape[1]:
        raise ValueError("prediction / anchor geometry mismatch")
    diagonal = torch.sqrt(anchors[..., 4].square() + anchors[..., 5].square())
    boxes = torch.empty_like(deltas)
    boxes[..., :2] = deltas[..., :2] * diagonal[..., None] + anchors[..., :2]
    boxes[..., 2] = deltas[..., 2] * anchors[..., 3] + anchors[..., 2]
    boxes[..., 3:6] = deltas[..., 3:6].exp() * anchors[..., 3:6]
    boxes[..., 6] = deltas[..., 6] + anchors[..., 6]
    boxes = boxes[..., [0, 1, 2, 5, 4, 3, 6]]  # xyzhwl-yaw -> xyzlwh-yaw
    if not torch.isfinite(boxes).all() or not torch.isfinite(scores).all():
        raise ValueError("nonfinite detector output; never silently drop bad boxes")
    records = []
    for index, sample_id in enumerate(sample_ids):
        ids = (scores[index] >= score_floor).nonzero(as_tuple=False).flatten()
        kept_boxes = boxes[index, ids].detach().cpu().tolist()
        kept_scores = scores[index, ids].detach().cpu().tolist()
        records.append({"sample_id": str(sample_id), "predictions": [
            {"prediction_id": f"anchor_{anchor:07d}", "class_name": "Vehicle", "score": score, "box": box}
            for anchor, score, box in zip(ids.cpu().tolist(), kept_scores, kept_boxes)]})
    return records


@torch.inference_mode()
def export_loader(model, loader, dataset, device, *, postprocess=True):
    from opencood.project.evaluation import postprocess_predictions
    was_training = model.training
    model.eval()
    records = []
    iterator = None
    try:
        iterator = iter(loader)
        for batch in iterator:
            ego = batch["ego"]
            output = model(to_device(select_model_inputs(ego), device), return_aux=False)
            decoded = decode_predictions(output, dataset.anchor_box, ego["sample_ids"])
            for batch_index, record in enumerate(decoded):
                sample = dataset.manifest["samples"][record["sample_id"]]
                record.update({key: sample[key] for key in ("split", "sequence", "timestamp", "ego_id", "agent_ids", "gt_sha256")})
                record.update(dataset="v2xr", evaluation_weather=dataset.weather,
                              protocol_sha256=dataset.manifest["protocol_sha256"])
                agent_metadata = ego["metadata"][batch_index]
                record.update(source_agent_ids=sample["agent_ids"], agent_ids=[item["agent_id"] for item in agent_metadata],
                              evaluated_agent_ids=[item["agent_id"] for item in agent_metadata],
                              agent_weather={item["agent_id"]: item["weather"] for item in agent_metadata})
                if postprocess:
                    # The evaluator owns the single frozen postprocessing contract.
                    record["predictions"], record["filter_counts"] = postprocess_predictions(record["predictions"], sample)
            records.extend(decoded)
    finally:
        from project_tools.run_experiments import shutdown_loader
        try:
            model.train(was_training)
        finally:
            shutdown_loader({"loader": loader, "iterator": iterator})
    return records


def write_predictions(records, path, metadata):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf8") as stream:
        for record in records:
            stream.write(json.dumps(record, allow_nan=False) + "\n")
    metadata = {**metadata, "predictions_file_sha256": file_sha256(path)}
    path.with_suffix(path.suffix + ".meta.json").write_text(json.dumps(metadata, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="cscwd_configs/project_v3.yaml")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", choices=["validate", "validation", "test"], default="validate")
    parser.add_argument("--weather", choices=["normal", "fog", "snow"], default="normal")
    parser.add_argument("--execute", action="store_true", help="without this flag only verify arguments")
    parser.add_argument("--allow-test-evaluation", action="store_true")
    args = parser.parse_args()
    args.split = "validate" if args.split == "validation" else args.split
    from opencood.project.config import load_config, file_sha256, config_hash
    from project_tools.run_experiments import build_model, make_eval_loader, artifact_metadata
    config = load_config(args.config)
    if args.weather == "snow" and args.split != "test":
        parser.error("Snow cannot be used for validation/model selection")
    if args.split == "test" and not args.allow_test_evaluation:
        parser.error("final test requires --allow-test-evaluation after method freezing")
    if not args.execute:
        print(json.dumps({"status": "preflight", **vars(args)}, indent=2))
        return
    # Standalone export must use the same deterministic FP32 reference as
    # in-run validation, including the explicit TF32 policy.
    import os
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(config["resources"]["cpu_threads"])
    seed_everything(config["experiment"]["seed"], config["training"]["deterministic"])
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = build_model(config, mode="export")
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if saved.get("schema_version") != config["version"] or saved.get("training_protocol") != config["experiment"]["training_protocol"] or saved["config_sha256"] != config_hash(config) or saved["train_state"]["selected_epoch"] < 0 or saved.get("metadata", {}).get("checkpoint_role") != "selected" or saved["train_state"]["epoch"] != saved["train_state"]["selected_epoch"] or saved.get("sampler", {}).get("next_batch") != 0:
        raise ValueError("export requires a selected checkpoint with matching configuration")
    expected_artifacts = artifact_metadata(config)
    for key, value in expected_artifacts.items():
        if saved.get("metadata", {}).get(key) != value:
            raise ValueError(f"checkpoint source/configured artifact mismatch: {key}")
    model.load_state_dict(saved["model"], strict=True)
    model.to(device)
    dataset, loader = make_eval_loader(config, args.split, args.weather)
    records = export_loader(model, loader, dataset, device)
    from opencood.project.evaluation import default_protocol, postprocess_hash
    write_predictions(records, args.output, {"config_sha256": config_hash(config), "checkpoint_sha256": file_sha256(args.checkpoint),
        "training_protocol": config["experiment"]["training_protocol"], "protocol": "project_fix_v1", "protocol_sha256": default_protocol()["protocol_sha256"], "postprocess_sha256": postprocess_hash(),
        "gt_manifest_sha256": file_sha256(Path(config["data"]["manifest_dir"]) / "eval_gt_manifest.json"),
        "source_kind": "retrained", "dataset": "v2xr", "split": args.split, "evaluation_weather": args.weather,
        "checkpoint_epoch": saved["train_state"]["selected_epoch"], "selected_epoch": saved["train_state"]["selected_epoch"],
        "postprocessed": True, "sample_count": len(records), "inference_precision": "fp32", "tf32": False})
    print(json.dumps({"status": "predictions_exported", "samples": len(records), "output": args.output}))


if __name__ == "__main__":
    main()
