#!/usr/bin/env bash
set -euo pipefail
source /root/autodl-tmp/CSCWD/setup/activate.sh
python -m pip check
python project_tools/check_environment.py
python project_tools/check_astyx_sample.py
python project_tools/check_v2xr_sample.py --gpu-step
