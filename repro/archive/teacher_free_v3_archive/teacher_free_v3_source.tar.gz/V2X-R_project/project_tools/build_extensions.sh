#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
: "${CUDA_HOME:=/usr/local/cuda}"
: "${TORCH_CUDA_ARCH_LIST:=8.9}"
: "${MAX_JOBS:=4}"
export CUDA_HOME TORCH_CUDA_ARCH_LIST MAX_JOBS
python opencood/utils/setup.py build_ext --inplace
python opencood/pcdet_utils/setup.py build_ext --inplace
