# Project configuration versions

Current entrypoints default to `project_v3.yaml` (C-AB); `project_v3_W_AB.yaml` is the weather template. Training protocol and config/checkpoint schema are `teacher_free_v3` / 3; scoring stays `project_fix_v1`. Outputs use `/root/autodl-tmp/CSCWD/outputs/teacher_free_v3`. Formal runs remain pending and require explicit launch.

Use FP32, microbatch 4, accumulation 2, effective batch 8, 8 workers, and activation checkpointing. All W S0/A/B/AB/SUP/M/N variants receive identical `provenance_v1` normal-slot perturbations (`probability=.5`, `drop_fraction=.2`, `inject_fraction=.05`, `max_offset_m=.3`), geometry, shared-layer initialization, update budget, GT/splits, and evaluator. C remains clean with negative-only type labels. Natural Fog unmatched points remain unknown; no teacher or clean feature targets enter training or inference.

V3 supplies detached current RMS amplitude to DEER's normalized control path and keeps type scores as SBR inputs while removing their extra multiplicative amplitude prior. N1 replaces RMS amplitude with a trainable, same-parameter-count normalized-mean descriptor; N2 restores only that multiplicative prior. M1–M6 retain the registered head/support/bound/identity/type-input controls. SUP uses ordinary routing/residuals with the same auxiliary labels and budget; it has similar capacity and is not strictly parameter matched. See `docs/02`, `docs/04`, and `docs/08` for formulas, measurements, and limits.

`experiment_matrix.json` registers 78 pending tasks (P0 body 26 + 8 mechanism tasks; P1 body 70 + 8). External baselines retain `baseline_adapter_pending`, unknown teacher cost, and method-native objectives pending audit; their shared input/budget comparison contract does not declare their own protocol implemented.

From the repository root after sourcing `/root/autodl-tmp/CSCWD/setup/activate.sh`:

```bash
python project_tools/run_experiments.py --config cscwd_configs/project_v3_W_AB.yaml
python project_tools/run_experiments.py --config cscwd_configs/project_v3_W_AB.yaml --mode smoke --steps 1 --warmup 0
python project_tools/benchmark_resources.py --config cscwd_configs/project_v3_W_AB.yaml --profiles fp32:4:8 --warmup 5 --steps 20
```

The first command only preflights; the others are bounded train-partition diagnostics. Short-run learning and resource results are not AP evidence. No test or Snow data is used for selection.

Root copies of superseded v1/v2 YAMLs and obsolete historical generators were removed after exact-byte archive checks. The frozen v2 source/config/tests/docs and original acceptance remain in [the minimal v2 archive](../../setup/teacher_free_v2_archive/README.md). Use an independently extracted copy to reproduce the historical baseline. Schema/source/config checks reject v2/v3 checkpoint mixing. The prior teacher/RMS matrix and exact configs remain in `archive/teacher_v1`, with its source under `setup/teacher_v1_archive`; current loaders reject version 1 and teacher/RMS artifact fields.
