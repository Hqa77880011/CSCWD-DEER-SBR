#!/usr/bin/env bash
# Source this file in a shell: source /root/autodl-tmp/CSCWD/setup/activate.sh
export CSCWD_ROOT=/root/autodl-tmp/CSCWD
source /root/miniconda3/etc/profile.d/conda.sh
conda activate "$CSCWD_ROOT/envs/cscwd"
export PYTHONNOUSERSITE=1
export CUDA_HOME=/usr/local/cuda
export TORCH_CUDA_ARCH_LIST=8.9
export MAX_JOBS="${MAX_JOBS:-4}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export OPENBLAS_NUM_THREADS=4
export MPLBACKEND=Agg
export PYTHONPATH="$CSCWD_ROOT/V2X-R_project${PYTHONPATH:+:$PYTHONPATH}"
cd "$CSCWD_ROOT/V2X-R_project" || return 1
