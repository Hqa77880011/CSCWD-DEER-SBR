"""Validate final bounded v3 evidence, including adverse results. No training."""
import json,re
from pathlib import Path
from opencood.project.config import load_config,file_sha256,require_matching_training_contract
from project_tools.run_experiments import source_tree_hash,data_contract_metadata
ROOT=Path('/root/autodl-tmp/CSCWD');REPO=ROOT/'V2X-R_project'
def read(name):return json.loads((ROOT/'setup'/name).read_text())
def output_path(report):
    p=Path(report['output'])
    return p if p.is_absolute() else (REPO/p).resolve()
source=source_tree_hash();config=load_config(REPO/'cscwd_configs/project_v3_W_AB.yaml')
reports={}
for label,name in [('mechanisms','teacher_free_v3_mechanisms.json'),('memory','teacher_free_v3_memory.json'),
                   ('dense_memory','teacher_free_v3_dense_memory.json'),('resume','teacher_free_v3_resume.json'),
                   ('stress_2109','teacher_free_v3_stress_2109.json'),('variant_paths','teacher_free_v3_variant_paths.json'),
                   ('type_audit','provenance_supervision_audit_v3.json'),('preflight_C','teacher_free_v3_preflight_C.json'),
                   ('preflight_W','teacher_free_v3_preflight_W.json'),('normal_bn','teacher_free_v3_normal_bn.json')]:
    path=ROOT/'setup'/name;r=read(name)
    if label in ('stress_2109','variant_paths'):
        assert r['source_sha256']==file_sha256(REPO/'project_tools/diagnose_modules.py')
        scope='diagnostic_entrypoint_file'
    elif label.startswith('preflight'):
        assert not r['formal_blockers'];scope='preflight_config_and_source_bound_replay'
    else:
        assert r.get('source_sha256',r.get('contract',{}).get('source_sha256'))==source,(label,'stale source')
        scope='source_tree'
    if label=='normal_bn':
        assert r['all_outputs_finite'] and r['buffers_restored']
        path_passed=None  # Finite is not an accepted inference stability test.
    elif label=='type_audit':
        assert r['formal_positive_supervision_ready'];path_passed=True
    elif label.startswith('preflight'):path_passed=True
    else:
        assert r['passed'],label;path_passed=True
    if 'source_unchanged' in r:assert r['source_unchanged']
    reports[label]={'path':str(path),'sha256':file_sha256(path),'engineering_path_passed':path_passed,'source_scope':scope}
bench=read('teacher_free_v3_resources.log');baseline=read('teacher_free_v3_paired_v2_resources.log')
assert bench['passed'] and bench['source_unchanged'] and bench['audit_contract']['source_sha256']==source
assert baseline['passed'] and baseline['source_unchanged'] and baseline['training_protocol']=='teacher_free_v2'
assert bench['training_protocol']=='teacher_free_v3' and bench['completed_optimizer_updates']==25
for key in data_contract_metadata(config):assert bench['audit_contract'][key]==baseline['audit_contract'][key]
def rows(r):return [json.loads(x) for x in (output_path(r)/'steps.rank0.jsonl').read_text().splitlines()]
a,b=rows(baseline),rows(bench);assert len(a)==len(b)==25
for left,right in zip(a,b):
    for key in ('agent_weather_counts','sensor_points','agents_per_micro','type_coverage','target_diagnostics'):
        assert left[key]==right[key],key
metadata=[json.loads((output_path(r)/'run_metadata.json').read_text()) for r in (baseline,bench)]
assert metadata[0]['shared_initialization_sha256']==metadata[1]['shared_initialization_sha256']
for track,variants in [('C',['S0','A','B','AB']),('W',['S0','A','B','AB','SUP','M1','M2','M3','M4','M5','M6'])]:
    configs=[load_config(REPO/f'cscwd_configs/project_v3_{track}_{v}.yaml') for v in variants]
    for c in configs[1:]:
        require_matching_training_contract(configs[0],c,'final matrix')
        assert configs[0]['loss']==c['loss']
configs=list((REPO/'cscwd_configs').glob('project_v3*.yaml'));assert len(configs)==19
for path in configs:load_config(path)
matrix=json.loads((REPO/'cscwd_configs/experiment_matrix.json').read_text())
assert len(matrix['runs'])==78 and all(r['status']=='pending' for r in matrix['runs'])
assert matrix['config_version']==matrix['checkpoint_schema_version']==3
log=ROOT/'setup/teacher_free_v3_tests_final.log';test_count=int(re.search(r'Ran (\d+) tests',log.read_text()).group(1));assert test_count==114 and log.read_text().rstrip().endswith('OK')
normal=read('teacher_free_v3_normal_bn.json');normal_v2=read('teacher_free_v3_v2_normal_bn.json')
assert normal_v2['all_outputs_finite'] and normal_v2['buffers_restored']
cleanup=read('teacher_free_v3_cleanup_manifest.json')
resource_keys=('effective_samples_per_second','mean_optimizer_step_seconds','mean_phase_seconds','data_wait_fraction','peak_allocated_gib','peak_reserved_gib','measured_gpu_util_mean','peak_cgroup_anon_gib','peak_cgroup_shmem_gib')
receipt={'schema':'teacher_free_v3_acceptance','training_protocol':'teacher_free_v3','evaluation_protocol':'project_fix_v1',
    'config_and_checkpoint_schema':3,'source_sha256':source,'data_contract':data_contract_metadata(config),
    'formal_experiments_started':False,'formal_ap_computed':False,'snow_or_test_used_for_tuning':False,
    'engineering_training_path_checks_passed':True,'normal_eval_stability_passed':False,'formal_launch_recommended':False,
    'acceptance_scope':'Training/gradient/resource/resume paths passed; severe short-trained BN eval sensitivity remains an explicit failed/unresolved check.',
    'teacher_networks':0,'precision':'fp32','tests':{'passed':test_count,'log':str(log),'sha256':file_sha256(log)},
    'reports':reports,'matched_input_counts_and_shared_initialization_verified':True,
    'resources':{'paired_v2':{k:baseline[k] for k in resource_keys},'final_v3':{k:bench[k] for k in resource_keys},
        'throughput_change_percent':100*(bench['effective_samples_per_second']/baseline['effective_samples_per_second']-1),
        'allocated_change_gib':bench['peak_allocated_gib']-baseline['peak_allocated_gib'],
        'allocated_change_percent':100*(bench['peak_allocated_gib']/baseline['peak_allocated_gib']-1),
        'warmup_updates_each':5,'timed_updates_each':20,'no_statistical_confidence_interval':True},
    'normal_bn_sensitivity':{'v2':normal_v2['mean_detection_loss'],'v3':normal['mean_detection_loss'],
        'source_reports':['setup/teacher_free_v3_v2_normal_bn.json','setup/teacher_free_v3_normal_bn.json'],
        'source_reports_sha256':{name:file_sha256(ROOT/'setup'/name) for name in ('teacher_free_v3_v2_normal_bn.json','teacher_free_v3_normal_bn.json')},
        'interpretation':'Both short-trained versions fail normal eval stability. Train-mode counterfactuals are not a valid replacement for evaluation. No BN protocol change adopted.'},
    'config_count':len(configs),'matrix_pending':78,'cleanup_manifest':str(ROOT/'setup/teacher_free_v3_cleanup_manifest.json'),
    'cleanup_summary':cleanup['summary'],
    'failure_evidence':{str(path):file_sha256(path) for path in [ROOT/'setup/teacher_free_v3_mechanisms_retain_graph_failed.log',
        ROOT/'setup/teacher_free_v3_v2_memory_hook_failed.json',ROOT/'setup/teacher_free_v3_v2_dense_memory_hook_failed.json',
        ROOT/'setup/teacher_free_v3_v2_allocator_probe.json']},
    'v2_source_archive_sha256':file_sha256(ROOT/'setup/teacher_free_v2_archive/teacher_free_v2_source.tar.gz'),
    'minimal_formal_control_after_bn_gate':['W seed17 S0','W seed17 A','W seed17 B','W seed17 AB','W seed17 SUP','W seed17 N1','W seed17 N2'],
    'limitations':['No AP improvement established','Target-local Radar support remains sparse','Normalized donor cosine does not establish semantic alignment',
        'Short-run BN inference stability failed in v2 and v3','One finite resource window does not certify a full epoch',
        'Astyx, strong-baseline adapters and DDP remain pending']}
paths=list((ROOT/'docs').glob('*.md'))+configs+[REPO/'cscwd_configs/experiment_matrix.json',REPO/'cscwd_configs/README.md',ROOT/'setup/teacher_free_v3_diagnostic_scope.json',ROOT/'setup/teacher_free_v3_cleanup_manifest.json',ROOT/'setup/teacher_free_v3_mechanism_findings.json',ROOT/'setup/teacher_free_v3_memory_interpretation.json',ROOT/'setup/create_v3_acceptance.py',ROOT/'setup/check_v3_normal_bn.py',ROOT/'setup/teacher_free_v3_checkpoint_dedup_audit.json',ROOT/'setup/README.txt',ROOT/'setup/create_v3_diagnostic_scope.py']
receipt['files']={str(path):file_sha256(path) for path in paths}
path=ROOT/'setup/teacher_free_v3_acceptance.json';path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps({'acceptance':str(path),'source_sha256':source,'training_paths_passed':True,'normal_eval_stability_passed':False,'tests':test_count,'formal_runs':0}))
