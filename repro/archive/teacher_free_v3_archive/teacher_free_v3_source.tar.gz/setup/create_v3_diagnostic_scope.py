"""Record exact train-only schedules used by bounded v3 diagnostics; no learning."""
import json
from pathlib import Path
from opencood.project.training import EpochBatchSampler
ROOT=Path('/root/autodl-tmp/CSCWD')
m=json.loads((ROOT/'datasets/v2xr/eval_gt_manifest.json').read_text())
ids=sorted(k for k,v in m['samples'].items() if v['split']=='train')
def schedule(size, updates, epoch=0):
    batches=list(EpochBatchSampler(size,4,2,17,epoch=epoch))[:updates*2]
    return [{'epoch':epoch,'micro_index':i,'sample_indices':b,'sample_ids':[ids[k] for k in b]} for i,b in enumerate(batches)]
r={'schema':'v3_bounded_train_diagnostic_scope_v1','formal_training_started':False,'ap_measured':False,
   'split':'train','allowed_weather':['normal','fog'],'seed':17,'training_micro_batch':4,'accumulation':2,
   'paired_benchmark_each_version':{'optimizer_updates':25,'warmup_updates':5,'measured_updates':20,'sample_presentations':200,'schedule':schedule(len(ids),25)},
   'paired_memory_each_version':{'optimizer_updates':3,'sample_presentations':24,'schedule':schedule(len(ids),3)},
   'dense_memory_each_version':{'optimizer_updates':3,'sample_presentations':24,'unique_sample_indices':[2138],'sample_ids':[ids[2138]]},
   'fixed_learning_v3':{'optimizer_updates':6,'sample_presentations':48,'unique_sample_indices':list(range(8)),'sample_ids':ids[:8],
       'extra_gradient_probes':'before/after learning: four independent objectives at micro4, no optimizer updates, buffers and RNG restored',
       'extra_counterfactuals':'first micro [0:4], A-disabled/B-disabled/donor-zero under eval BN; no updates',
       'empty_modalities':'sample0: no Radar / no LiDAR / both absent, forward/backward only'},
   'resume_each_branch':{'continuous_updates':5,'split_updates':[2,3],'sample_presentations_across_both_branches':80,
       'schedule_32_train_subset_epoch0':schedule(32,4),'epoch1_first_update':schedule(32,1,epoch=1)},
   'type_audit':{'updates':0,'samples':32,'indices_source':'provenance_supervision_audit_v3.json sample_indices'},
   'bounds':'No validation/test/Snow point inputs or AP selection. Fixed GT manifest metadata contains all splits but only train samples are selected.'}
r.update(json.loads('{"dense_2109_supplemental": {"optimizer_updates": 2, "micro_batch_size": 4, "accumulation_steps_in_this_stress_helper": 1, "sample_presentations": 8, "unique_sample_indices": [2109], "sample_ids": ["train/2024_06_25_15_46_09/000296"], "interpretation": "Auxiliary single-micro stress only, not effective8 training comparison"}, "fp32_variant_paths": {"variants": ["S0", "A", "B", "AB", "SUP", "N1", "N2"], "optimizer_updates": 0, "sample_indices": [0, 1, 2, 3, 4, 5, 6, 7], "one_effective_forward_backward_per_variant": true}, "normal_bn_each_version": {"optimizer_updates": 0, "checkpoint_updates": 25, "sample_indices": [0, 1, 2, 3, 4, 5, 6, 7], "weather": "normal", "augmentation": false, "forward_modes": ["eval_running_statistics", "training_batch_statistics"], "bn_buffers_restored": true, "sample_presentations_per_version": 16}, "all_attempts_in_this_work_session": [{"implementation": "frozen_v2", "component": "paired benchmark", "updates": 25, "samples_presented": 200}, {"implementation": "frozen_v2_plus_instrumentation", "component": "ordinary+dense+allocator probe", "updates": 7, "samples_presented": 56}, {"implementation": "frozen_v2_plus_instrumentation", "component": "failed hook probes (2 attempts)", "updates": 0, "failure": "hook replaced VFE output"}, {"implementation": "v3_f023a", "component": "initial retain_graph mechanism audit", "updates": 0, "failure": "retained graphs OOM"}, {"implementation": "v3_f023a", "component": "preliminary ordinary+dense profiles", "updates": 6, "samples_presented": 48}, {"implementation": "v3_f023a", "component": "preliminary benchmark", "updates": 25, "samples_presented": 200}, {"implementation": "v3_f023a", "component": "preliminary 5 vs 2+3 resume", "updates": 10, "samples_presented": 80}, {"implementation": "v3_c02a", "component": "fixed learning", "updates": 6, "samples_presented": 48}, {"implementation": "v3_c02a", "component": "ordinary+dense profiles", "updates": 6, "samples_presented": 48}, {"implementation": "v3_c02a", "component": "final benchmark", "updates": 25, "samples_presented": 200}, {"implementation": "v3_c02a", "component": "supplemental dense2109 single-micro stress", "updates": 2, "samples_presented": 8}, {"implementation": "v3_c02a", "component": "final 5 vs 2+3 resume", "updates": 10, "samples_presented": 80}, {"implementation": "v3_c02a", "component": "seven variant paths, independent gradient probes, counterfactuals, three empty modalities, Normal BN sensitivity, CPU support/source replay", "updates": 0}], "total_new_optimizer_updates": {"v2": 32, "v3": 90}}'))
(ROOT/'setup/teacher_free_v3_diagnostic_scope.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print('scope saved; no training performed')
