"""Zero-update train-Normal BN sensitivity on an existing v3 diagnostic checkpoint."""
import argparse,json,os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
from pathlib import Path
import torch
from opencood.project.training import seed_everything,to_device,select_model_inputs
from project_tools.run_experiments import build_components,source_tree_hash
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--checkpoint',required=True)
p.add_argument('--output',required=True)
a=p.parse_args()
saved=torch.load(a.checkpoint,map_location='cpu',weights_only=False)
c=saved['config']
assert c['version'] in (2,3)
assert saved['training_protocol']==f"teacher_free_v{c['version']}" and saved['schema_version']==c['version']
assert saved['metadata']['source_sha256']==source_tree_hash()
seed_everything(c['experiment']['seed'],True)
torch.set_num_threads(c['resources']['cpu_threads'])
dataset,model,criterion=build_components(c)
# Same fixed train GT, genuine Normal points, no training perturbations/geometry.
dataset.training=False;dataset.weather='normal';dataset.augment=False
batches=[dataset.collate_batch([dataset[i] for i in range(start,start+4)]) for start in (0,4)]
model.load_state_dict(saved['model'],strict=True)
device=torch.device('cuda:0');model.to(device);criterion.to(device)
buffers={k:v.clone() for k,v in model.named_buffers()}
report={'schema':f"v{c['version']}_train_normal_bn_sensitivity_v1",'training_protocol':saved['training_protocol'],'split':'train','weather':'normal','sample_indices':list(range(8)),
        'sample_ids':[sid for b in batches for sid in b['ego']['sample_ids']], 'optimizer_updates':0,
        'checkpoint_optimizer_updates':saved['train_state']['optimizer_steps'],'checkpoint':str(Path(a.checkpoint).resolve()),
        'source_sha256':source_tree_hash(),'micro_batch_size':4,'formal_experiment_started':False,'ap_measured':False,'modes':{}}
with torch.no_grad():
 for mode in ('eval_running_statistics','training_batch_statistics'):
  model.train(mode=='training_batch_statistics')
  rows=[]
  for batch in batches:
   for key,value in model.named_buffers():value.copy_(buffers[key])
   output=model(to_device(select_model_inputs(batch['ego']),device),return_aux=False)
   loss=criterion.detection_loss(output,to_device(batch['ego']['label_dict'],device))
   rows.append({'detection_loss':float(loss),'finite':bool(torch.isfinite(loss)) and all(bool(torch.isfinite(x).all()) for x in output.values()),
                'psm_abs_max':float(output['psm'].abs().max()),'rm_abs_max':float(output['rm'].abs().max())})
   del output,loss
  report['modes'][mode]=rows
 for key,value in model.named_buffers():value.copy_(buffers[key])
report['buffers_restored']=all(torch.equal(value,buffers[key]) for key,value in model.named_buffers())
means={mode:sum(row['detection_loss'] for row in rows)/len(rows) for mode,rows in report['modes'].items()}
report['mean_detection_loss']=means
report['eval_over_training_batch_loss_ratio']=means['eval_running_statistics']/max(means['training_batch_statistics'],1e-12)
report['all_outputs_finite']=all(row['finite'] for rows in report['modes'].values() for row in rows)
report['interpretation']='Zero-update sensitivity only. BN batch-stat mode is a diagnostic counterfactual, not a changed formal inference protocol or AP. Large eval/batch discrepancy requires investigation before formal comparison; no calibration or normalization setting is adopted.'
Path(a.output).write_text(json.dumps(report,indent=2,allow_nan=False))
print(json.dumps(report,indent=2))
