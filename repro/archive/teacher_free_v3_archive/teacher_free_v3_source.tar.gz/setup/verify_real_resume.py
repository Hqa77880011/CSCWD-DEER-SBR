"""Bounded GPU smoke: 5 continuous updates versus 2 + resume 3, crossing epoch."""
import argparse,json,subprocess,sys,time
from copy import deepcopy
from pathlib import Path
import numpy as np
import torch
import yaml

REPO=Path('/root/autodl-tmp/CSCWD/V2X-R_project')

def same(a,b):
    if torch.is_tensor(a):return torch.is_tensor(b) and torch.equal(a,b)
    if isinstance(a,np.ndarray):return isinstance(b,np.ndarray) and np.array_equal(a,b)
    if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return type(a)==type(b) and len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return type(a)==type(b) and a==b

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True)
    p.add_argument('--output',default='/root/autodl-tmp/CSCWD/setup/project_real_resume.json')
    args=p.parse_args();config=yaml.safe_load(Path(args.config).read_text())
    root=Path('/root/autodl-tmp/CSCWD/outputs/resume_verification');root.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%d_%H%M%S',time.gmtime());paths={}
    for name in ('continuous','resumed'):
        c=deepcopy(config);c['experiment']['run_id']=f'{stamp}_{name}'
        c['artifacts']['output_root']=str(root)
        path=root/(c['experiment']['run_id']+'.yaml');path.write_text(yaml.safe_dump(c,sort_keys=False))
        paths[name]=(path,root/c['experiment']['run_id']/'smoke')
    def run(name,steps,resume=False):
        config_path,out=paths[name]
        cmd=[sys.executable,str(REPO/'project_tools/run_experiments.py'),'--config',str(config_path),
             '--mode','smoke','--steps',str(steps),'--warmup','0']
        if resume:cmd+=['--resume',str(out)]
        with (root/f'{stamp}_{name}_{steps}.log').open('w') as log:
            subprocess.run(cmd,cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
    run('continuous',5);run('resumed',2);run('resumed',3,True)
    a,b=[torch.load(paths[name][1]/'latest.rank0.pt',map_location='cpu',weights_only=False) for name in ('continuous','resumed')]
    fields=('model','optimizer','scheduler','scaler','train_state','sampler','rng')
    comparisons={key:same(a[key],b[key]) for key in fields}
    def rows(name):return [json.loads(line) for line in (paths[name][1]/'steps.rank0.jsonl').read_text().splitlines()]
    ar,br=rows('continuous'),rows('resumed')
    comparisons['step_losses_exact']=[r['loss'] for r in ar]==[r['loss'] for r in br]
    comparisons['weather_and_agents_exact']=[(r['agent_weather_counts'],r['agents_per_micro']) for r in ar]==[(r['agent_weather_counts'],r['agents_per_micro']) for r in br]
    report={'passed':all(comparisons.values()),'formal_experiment_started':False,
            'protocol':'5 bounded smoke updates versus 2 + resumed 3; 32-train-frame diagnostic subset crosses epoch boundary',
            'precision':config['training']['precision'],'micro_batch_size':config['training']['micro_batch_size'],
            'comparisons':comparisons,'train_state':a['train_state'],'sampler':a['sampler'],
            'source_sha256':a['metadata']['source_sha256'],
            'checkpoints':{name:str(pair[1]/'latest.rank0.pt') for name,pair in paths.items()}}
    # Unselected diagnostic scores are not AP results.
    report['train_state']['best_score']=None
    Path(args.output).write_text(json.dumps(report,indent=2,allow_nan=False));print(json.dumps(report,indent=2))
    if not report['passed']:raise SystemExit(2)

if __name__=='__main__':main()
