import torch
import torch.nn as nn


from opencood.models.common_modules.pillar_vfe import PillarVFE
from opencood.models.common_modules.point_pillar_scatter import PointPillarScatter
from opencood.models.common_modules.att_bev_backbone import AttBEVBackbone


class PFAnet(nn.Module):
    def __init__(self, args):
        super(PFAnet, self).__init__()

        # PIllar VFE
        self.modality = 'processed_lidar'
        if 'use_modality' in args.keys():
            self.modality = args['use_modality']
        
        self.pillar_vfe = PillarVFE(args['pillar_vfe'],
                                    num_point_features=4,
                                    voxel_size=args['voxel_size'],
                                    point_cloud_range=args['lidar_range'])
        self.scatter = PointPillarScatter(args['point_pillar_scatter'])
        # self.backbone = AttBEVBackbone(args['base_bev_backbone'], 64)
        self.backbone = AttBEVBackbone(args['base_bev_backbone'], 64)

        self.cls_head = nn.Conv2d(128 * 3, args['anchor_number'],
                                  kernel_size=1)
        self.reg_head = nn.Conv2d(128 * 3, 7 * args['anchor_num'],
                                  kernel_size=1)

    def forward(self, data_dict):

        voxel_features = data_dict[self.modality]['voxel_features']
        voxel_coords = data_dict[self.modality]['voxel_coords']
        voxel_num_points = data_dict[self.modality]['voxel_num_points']
        record_len = data_dict['record_len']

        batch_dict = {'voxel_features': voxel_features,
                      'voxel_coords': voxel_coords,
                      'voxel_num_points': voxel_num_points,
                      'record_len': record_len}

        batch_dict = self.pillar_vfe(batch_dict)
        batch_dict = self.scatter(batch_dict)
        batch_dict = self.backbone(batch_dict)

        spatial_features_2d = batch_dict['spatial_features_2d']
        

        psm = self.cls_head(spatial_features_2d)
        rm = self.reg_head(spatial_features_2d)
        
        output_dict = {'psm': psm,
                       'rm': rm}

        return output_dict